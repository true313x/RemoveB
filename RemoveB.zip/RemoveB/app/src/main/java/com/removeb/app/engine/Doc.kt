package com.removeb.app.engine

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorSpace
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.net.Uri
import java.nio.ByteBuffer
import java.util.Arrays
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

data class IRect(val l: Int, val t: Int, val r: Int, val b: Int)

private const val TILE = 64

/** Tile based copy-on-write undo history for the alpha mask. */
class History(private val w: Int, private val h: Int) {
    class Entry { val tiles = HashMap<Int, ByteArray>() }

    private val tilesX = (w + TILE - 1) / TILE
    private val undoStack = ArrayList<Entry>()
    private val redoStack = ArrayList<Entry>()
    private var cur: Entry? = null

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    fun begin() { cur = Entry() }

    fun touch(m: ByteArray, l: Int, t: Int, r: Int, b: Int) {
        val e = cur ?: return
        val tx0 = max(l, 0) / TILE
        val tx1 = min(r, w - 1) / TILE
        val ty0 = max(t, 0) / TILE
        val ty1 = min(b, h - 1) / TILE
        for (ty in ty0..ty1) for (tx in tx0..tx1) {
            val key = ty * tilesX + tx
            if (!e.tiles.containsKey(key)) e.tiles[key] = read(m, tx, ty)
        }
    }

    fun commit() {
        val e = cur ?: return
        cur = null
        if (e.tiles.isEmpty()) return
        undoStack.add(e)
        if (undoStack.size > 40) undoStack.removeAt(0)
        redoStack.clear()
    }

    fun cancel(m: ByteArray): IRect? {
        val e = cur ?: return null
        cur = null
        return if (e.tiles.isEmpty()) null else swap(e, m)
    }

    fun undo(m: ByteArray): IRect? {
        if (undoStack.isEmpty()) return null
        val e = undoStack.removeAt(undoStack.size - 1)
        redoStack.add(e)
        return swap(e, m)
    }

    fun redo(m: ByteArray): IRect? {
        if (redoStack.isEmpty()) return null
        val e = redoStack.removeAt(redoStack.size - 1)
        undoStack.add(e)
        return swap(e, m)
    }

    private fun swap(e: Entry, m: ByteArray): IRect {
        var l = Int.MAX_VALUE; var t = Int.MAX_VALUE; var r = -1; var b = -1
        for (en in e.tiles.entries) {
            val tx = en.key % tilesX
            val ty = en.key / tilesX
            val now = read(m, tx, ty)
            write(m, tx, ty, en.value)
            en.setValue(now)
            val x0 = tx * TILE
            val y0 = ty * TILE
            l = min(l, x0); t = min(t, y0)
            r = max(r, min(w, x0 + TILE) - 1); b = max(b, min(h, y0 + TILE) - 1)
        }
        return IRect(l, t, r, b)
    }

    private fun read(m: ByteArray, tx: Int, ty: Int): ByteArray {
        val x0 = tx * TILE; val y0 = ty * TILE
        val tw = min(TILE, w - x0); val th = min(TILE, h - y0)
        val out = ByteArray(tw * th)
        for (j in 0 until th) System.arraycopy(m, (y0 + j) * w + x0, out, j * tw, tw)
        return out
    }

    private fun write(m: ByteArray, tx: Int, ty: Int, data: ByteArray) {
        val x0 = tx * TILE; val y0 = ty * TILE
        val tw = min(TILE, w - x0); val th = min(TILE, h - y0)
        for (j in 0 until th) System.arraycopy(data, j * tw, m, (y0 + j) * w + x0, tw)
    }
}

/** Redmean weighted RGB distance (squared scale, max about 585k). */
private fun dist(a: Int, b: Int): Int {
    val r1 = (a shr 16) and 255; val g1 = (a shr 8) and 255; val b1 = a and 255
    val r2 = (b shr 16) and 255; val g2 = (b shr 8) and 255; val b2 = b and 255
    val rm = (r1 + r2) shr 1
    val dr = r1 - r2; val dg = g1 - g2; val db = b1 - b2
    return (((512 + rm) * dr * dr) shr 8) + 4 * dg * dg + (((767 - rm) * db * db) shr 8)
}

class Doc(val w: Int, val h: Int, private val src: IntArray) {
    /** 255 = keep, 0 = erased. */
    val mask = ByteArray(w * h).also { Arrays.fill(it, 255.toByte()) }
    val bitmap: Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    private val history = History(w, h)
    private val full: ByteArray by lazy { ByteArray(w * h).also { Arrays.fill(it, 255.toByte()) } }
    var overlay = false

    val canUndo: Boolean get() = history.canUndo
    val canRedo: Boolean get() = history.canRedo

    // ---------- rendering ----------

    private fun pix(i: Int, m: ByteArray, ov: Boolean): Int {
        val s = src[i]
        val sa = s ushr 24
        val mv = m[i].toInt() and 0xFF
        if (!ov) {
            val a = if (mv == 255) sa else (sa * mv + 127) / 255
            return if (a == 0) 0 else (a shl 24) or (s and 0xFFFFFF)
        }
        val k = (255 - mv) * 140 / 255
        val rr = (((s shr 16) and 255) * (255 - k) + 0xE5 * k) / 255
        val gg = (((s shr 8) and 255) * (255 - k) + 0x39 * k) / 255
        val bb = ((s and 255) * (255 - k) + 0x35 * k) / 255
        return (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
    }

    private fun renderTo(dst: Bitmap, l: Int, t: Int, r: Int, b: Int, m: ByteArray, ov: Boolean, dx: Int, dy: Int) {
        val rw = r - l + 1
        val band = 256
        val buf = IntArray(rw * min(band, b - t + 1))
        var y = t
        while (y <= b) {
            val yh = min(b, y + band - 1)
            var k = 0
            for (yy in y..yh) {
                var i = yy * w + l
                for (x in l..r) { buf[k++] = pix(i, m, ov); i++ }
            }
            dst.setPixels(buf, 0, rw, l - dx, y - dy, rw, yh - y + 1)
            y = yh + 1
        }
    }

    fun refresh(l0: Int, t0: Int, r0: Int, b0: Int, m: ByteArray = mask) {
        val l = max(0, l0); val t = max(0, t0); val r = min(w - 1, r0); val b = min(h - 1, b0)
        if (l > r || t > b) return
        renderTo(bitmap, l, t, r, b, m, overlay, 0, 0)
    }

    fun refreshAll(m: ByteArray = mask) = refresh(0, 0, w - 1, h - 1, m)

    fun showOriginal() = renderTo(bitmap, 0, 0, w - 1, h - 1, full, false, 0, 0)

    // ---------- history ----------

    fun beginOp() = history.begin()
    fun endOp() = history.commit()
    fun cancelOp() { history.cancel(mask)?.let { refresh(it.l, it.t, it.r, it.b) } }

    fun undo(): Boolean {
        val r = history.undo(mask) ?: return false
        refresh(r.l, r.t, r.r, r.b); return true
    }

    fun redo(): Boolean {
        val r = history.redo(mask) ?: return false
        refresh(r.l, r.t, r.r, r.b); return true
    }

    // ---------- tools ----------

    /** Colour fill. tol in 0..100. */
    fun fill(sx: Int, sy: Int, tol: Float, contiguous: Boolean, erase: Boolean) {
        if (sx < 0 || sy < 0 || sx >= w || sy >= h) return
        val seed = src[sy * w + sx]
        val td = tol * 4f
        val thr = (td * td).toInt()
        val vis = BooleanArray(w * h)
        var l = w; var t = h; var r = -1; var b = -1
        if (contiguous) {
            var stk = IntArray(4096)
            var sp = 0
            fun push(v: Int) {
                if (sp == stk.size) stk = stk.copyOf(sp * 2)
                stk[sp++] = v
            }
            push(sy * w + sx)
            while (sp > 0) {
                val p = stk[--sp]
                if (vis[p]) continue
                val y = p / w
                val x = p - y * w
                val row = y * w
                var xl = x
                while (xl > 0 && !vis[row + xl - 1] && dist(seed, src[row + xl - 1]) <= thr) xl--
                var xr = x
                while (xr < w - 1 && !vis[row + xr + 1] && dist(seed, src[row + xr + 1]) <= thr) xr++
                for (i in xl..xr) vis[row + i] = true
                if (xl < l) l = xl
                if (xr > r) r = xr
                if (y < t) t = y
                if (y > b) b = y
                for (dy in -1..1 step 2) {
                    val ny = y + dy
                    if (ny < 0 || ny >= h) continue
                    val nrow = ny * w
                    var run = false
                    for (i in xl..xr) {
                        val ok = !vis[nrow + i] && dist(seed, src[nrow + i]) <= thr
                        if (ok) {
                            if (!run) { push(nrow + i); run = true }
                        } else run = false
                    }
                }
            }
        } else {
            for (y in 0 until h) {
                val row = y * w
                for (x in 0 until w) {
                    if (dist(seed, src[row + x]) <= thr) {
                        vis[row + x] = true
                        if (x < l) l = x
                        if (x > r) r = x
                        if (y < t) t = y
                        if (y > b) b = y
                    }
                }
            }
        }
        if (r < 0) return
        history.touch(mask, l, t, r, b)
        val v: Byte = if (erase) 0 else 255.toByte()
        for (y in t..b) {
            val row = y * w
            for (x in l..r) if (vis[row + x]) mask[row + x] = v
        }
        refresh(l, t, r, b)
    }

    /** Soft round brush. hardness 0..1, flow 0..1. */
    fun brushDab(cx: Float, cy: Float, r: Float, hardness: Float, flow: Float, erase: Boolean) {
        val ext = r + 1f
        val x0 = max(0, floor(cx - ext).toInt()); val x1 = min(w - 1, ceil(cx + ext).toInt())
        val y0 = max(0, floor(cy - ext).toInt()); val y1 = min(h - 1, ceil(cy + ext).toInt())
        if (x0 > x1 || y0 > y1) return
        history.touch(mask, x0, y0, x1, y1)
        val inner = hardness.coerceIn(0f, 0.99f)
        for (y in y0..y1) {
            val dy = y + 0.5f - cy
            for (x in x0..x1) {
                val dx = x + 0.5f - cx
                val d = sqrt(dx * dx + dy * dy)
                val cover = (r - d + 0.5f).coerceIn(0f, 1f)
                if (cover <= 0f) continue
                val tt = d / r
                var fall = if (tt <= inner) 1f else (1f - (tt - inner) / (1f - inner)).coerceIn(0f, 1f)
                fall = fall * fall * (3f - 2f * fall)
                val e = cover * fall * flow
                val i = y * w + x
                val m = mask[i].toInt() and 0xFF
                val nm = if (erase) floor(m * (1f - e)).toInt() else ceil(m + (255 - m) * e).toInt()
                mask[i] = nm.coerceIn(0, 255).toByte()
            }
        }
        refresh(x0, y0, x1, y1)
    }

    private fun avg3(cx: Int, cy: Int): Int {
        var r = 0; var g = 0; var b = 0; var n = 0
        for (y in max(0, cy - 1)..min(h - 1, cy + 1)) for (x in max(0, cx - 1)..min(w - 1, cx + 1)) {
            val c = src[y * w + x]
            r += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255; n++
        }
        return (0xFF shl 24) or ((r / n) shl 16) or ((g / n) shl 8) or (b / n)
    }

    /** Edge aware region growing limited to a disc of radius r. tol/edge 0..100. */
    fun magicDab(cx: Int, cy: Int, r: Int, tol: Float, edge: Float, erase: Boolean) {
        if (cx < 0 || cy < 0 || cx >= w || cy >= h) return
        val x0 = max(0, cx - r); val x1 = min(w - 1, cx + r)
        val y0 = max(0, cy - r); val y1 = min(h - 1, cy + r)
        val bw = x1 - x0 + 1
        val bh = y1 - y0 + 1
        val ref = avg3(cx, cy)
        val td = tol * 4f
        val tolSq = (td * td).toInt()
        val sd = 120f - (edge / 100f) * 112f
        val stepSq = (sd * sd).toInt()
        val seen = BooleanArray(bw * bh)
        val q = IntArray(bw * bh)
        var head = 0
        var tail = 0
        val s0 = (cy - y0) * bw + (cx - x0)
        seen[s0] = true
        q[tail++] = s0
        val rr = r * r
        while (head < tail) {
            val p = q[head++]
            val py = p / bw
            val px = p - py * bw
            val pc = src[(py + y0) * w + px + x0]
            for (k in 0 until 4) {
                val nx = px + (if (k == 0) 1 else if (k == 1) -1 else 0)
                val ny = py + (if (k == 2) 1 else if (k == 3) -1 else 0)
                if (nx < 0 || ny < 0 || nx >= bw || ny >= bh) continue
                val ni = ny * bw + nx
                if (seen[ni]) continue
                val dx = nx + x0 - cx
                val dy = ny + y0 - cy
                if (dx * dx + dy * dy > rr) continue
                val nc = src[(ny + y0) * w + nx + x0]
                if (dist(pc, nc) <= stepSq && dist(ref, nc) <= tolSq) {
                    seen[ni] = true
                    q[tail++] = ni
                }
            }
        }
        history.touch(mask, x0, y0, x1, y1)
        val v: Byte = if (erase) 0 else 255.toByte()
        for (i in 0 until tail) {
            val p = q[i]
            val py = p / bw
            val px = p - py * bw
            mask[(py + y0) * w + px + x0] = v
        }
        refresh(x0, y0, x1, y1)
    }

    private fun applyCov(i: Int, a: Int, erase: Boolean) {
        if (a == 0) return
        val m = mask[i].toInt() and 0xFF
        val nm = if (erase) m * (255 - a) / 255 else m + (255 - m) * a / 255
        mask[i] = nm.toByte()
    }

    /** Anti-aliased polygon selection. Path is in image coordinates. */
    fun lasso(path: Path, outside: Boolean, erase: Boolean) {
        val rf = RectF()
        path.computeBounds(rf, true)
        val l = max(0, floor(rf.left).toInt() - 1)
        val t = max(0, floor(rf.top).toInt() - 1)
        val r = min(w - 1, ceil(rf.right).toInt() + 1)
        val b = min(h - 1, ceil(rf.bottom).toInt() + 1)
        val bw = r - l + 1
        val bh = b - t + 1
        if (bw <= 0 || bh <= 0) return
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ALPHA_8)
        val cv = Canvas(bmp)
        cv.translate(-l.toFloat(), -t.toFloat())
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = 0xFF000000.toInt()
        }
        path.close()
        cv.drawPath(path, paint)
        val stride = bmp.rowBytes
        val buf = ByteBuffer.allocate(stride * bh)
        bmp.copyPixelsToBuffer(buf)
        bmp.recycle()
        val cov = buf.array()
        if (!outside) {
            history.touch(mask, l, t, r, b)
            for (y in t..b) for (x in l..r) {
                applyCov(y * w + x, cov[(y - t) * stride + (x - l)].toInt() and 255, erase)
            }
            refresh(l, t, r, b)
        } else {
            history.touch(mask, 0, 0, w - 1, h - 1)
            for (y in 0 until h) for (x in 0 until w) {
                val inside = x in l..r && y in t..b
                val a0 = if (inside) cov[(y - t) * stride + (x - l)].toInt() and 255 else 0
                applyCov(y * w + x, 255 - a0, erase)
            }
            refreshAll()
        }
    }

    fun invert() {
        history.begin()
        history.touch(mask, 0, 0, w - 1, h - 1)
        for (i in mask.indices) mask[i] = (255 - (mask[i].toInt() and 255)).toByte()
        history.commit()
        refreshAll()
    }

    fun resetMask() {
        history.begin()
        history.touch(mask, 0, 0, w - 1, h - 1)
        Arrays.fill(mask, 255.toByte())
        history.commit()
        refreshAll()
    }

    // ---------- edge refinement ----------

    /** shift: -10..10 (negative shrinks the kept area), smooth/feather: radius in px. */
    fun refined(shift: Int, smooth: Int, feather: Int): ByteArray {
        val a = mask.copyOf()
        if (shift != 0) morph(a, w, h, kotlin.math.abs(shift), shift > 0)
        if (smooth > 0) {
            repeat(2) { boxBlur(a, w, h, smooth) }
            for (i in a.indices) {
                val v = ((a[i].toInt() and 255) - 128) * 6 + 128
                a[i] = v.coerceIn(0, 255).toByte()
            }
        }
        if (feather > 0) repeat(2) { boxBlur(a, w, h, feather) }
        return a
    }

    fun commitRefined(a: ByteArray) {
        history.begin()
        history.touch(mask, 0, 0, w - 1, h - 1)
        System.arraycopy(a, 0, mask, 0, a.size)
        history.commit()
        refreshAll()
    }

    // ---------- export ----------

    fun export(trim: Boolean): Bitmap {
        var l = 0; var t = 0; var r = w - 1; var b = h - 1
        if (trim) {
            l = w; t = h; r = -1; b = -1
            for (y in 0 until h) {
                val row = y * w
                for (x in 0 until w) {
                    val i = row + x
                    if ((src[i] ushr 24) * (mask[i].toInt() and 255) > 0) {
                        if (x < l) l = x
                        if (x > r) r = x
                        if (y < t) t = y
                        if (y > b) b = y
                    }
                }
            }
            if (r < 0) { l = 0; t = 0; r = w - 1; b = h - 1 }
        }
        val out = Bitmap.createBitmap(r - l + 1, b - t + 1, Bitmap.Config.ARGB_8888)
        renderTo(out, l, t, r, b, mask, false, l, t)
        return out
    }
}

private fun boxBlur(a: ByteArray, w: Int, h: Int, r: Int) {
    if (r <= 0) return
    val d = 2 * r + 1
    val tmp = ByteArray(a.size)
    for (y in 0 until h) {
        val row = y * w
        var sum = 0
        for (i in -r..r) sum += a[row + min(max(i, 0), w - 1)].toInt() and 255
        for (x in 0 until w) {
            tmp[row + x] = ((sum + d / 2) / d).toByte()
            sum += (a[row + min(x + r + 1, w - 1)].toInt() and 255) - (a[row + max(x - r, 0)].toInt() and 255)
        }
    }
    val sum = IntArray(w)
    for (i in -r..r) {
        val row = min(max(i, 0), h - 1) * w
        for (x in 0 until w) sum[x] += tmp[row + x].toInt() and 255
    }
    for (y in 0 until h) {
        val o = y * w
        for (x in 0 until w) a[o + x] = ((sum[x] + d / 2) / d).toByte()
        val addRow = min(y + r + 1, h - 1) * w
        val subRow = max(y - r, 0) * w
        for (x in 0 until w) sum[x] += (tmp[addRow + x].toInt() and 255) - (tmp[subRow + x].toInt() and 255)
    }
}

private fun morph(a: ByteArray, w: Int, h: Int, r: Int, dilate: Boolean) {
    val tmp = ByteArray(a.size)
    for (y in 0 until h) {
        val row = y * w
        for (x in 0 until w) {
            val lo = max(0, x - r)
            val hi = min(w - 1, x + r)
            var v = if (dilate) 0 else 255
            for (k in lo..hi) {
                val s = a[row + k].toInt() and 255
                if (dilate) { if (s > v) v = s } else if (s < v) v = s
            }
            tmp[row + x] = v.toByte()
        }
    }
    val acc = IntArray(w)
    for (y in 0 until h) {
        val lo = max(0, y - r)
        val hi = min(h - 1, y + r)
        Arrays.fill(acc, if (dilate) 0 else 255)
        for (k in lo..hi) {
            val base = k * w
            for (x in 0 until w) {
                val s = tmp[base + x].toInt() and 255
                if (dilate) { if (s > acc[x]) acc[x] = s } else if (s < acc[x]) acc[x] = s
            }
        }
        val o = y * w
        for (x in 0 until w) a[o + x] = acc[x].toByte()
    }
}

fun decodeDoc(resolver: ContentResolver, uri: Uri, maxEdge: Int): Doc {
    val source = ImageDecoder.createSource(resolver, uri)
    val bmp = ImageDecoder.decodeBitmap(source) { dec, info, _ ->
        val iw = info.size.width
        val ih = info.size.height
        val s = min(1f, maxEdge.toFloat() / max(iw, ih))
        if (s < 1f) dec.setTargetSize(max(1, (iw * s).roundToInt()), max(1, (ih * s).roundToInt()))
        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        dec.setTargetColorSpace(ColorSpace.get(ColorSpace.Named.SRGB))
    }
    val w = bmp.width
    val h = bmp.height
    val px = IntArray(w * h)
    bmp.getPixels(px, 0, w, 0, 0, w, h)
    bmp.recycle()
    return Doc(w, h, px)
}
