@file:OptIn(ExperimentalMaterial3Api::class)

package com.removeb.app.ui

import android.content.Intent
import androidx.annotation.StringRes
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Brush
import androidx.compose.material.icons.rounded.Compare
import androidx.compose.material.icons.rounded.FitScreen
import androidx.compose.material.icons.rounded.HighlightAlt
import androidx.compose.material.icons.rounded.InvertColors
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.SaveAlt
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.removeb.app.EditorViewModel
import com.removeb.app.EditorViewModel.Bg
import com.removeb.app.EditorViewModel.Tool
import com.removeb.app.R
import com.removeb.app.engine.makeChecker
import kotlinx.coroutines.flow.receiveAsFlow
import kotlin.math.roundToInt

private fun bgColor(b: Bg): Int = when (b) {
    Bg.CHECKER, Bg.WHITE -> 0xFFFFFFFF
    Bg.BLACK -> 0xFF000000
    Bg.GREEN -> 0xFF00B140
    Bg.MAGENTA -> 0xFFFF00FF
}.toInt()

@Composable
fun EditorScreen(vm: EditorViewModel, onNew: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current.density
    LaunchedEffect(density) { vm.density = density }
    val snack = remember { SnackbarHostState() }
    var menu by remember { mutableStateOf(false) }
    var exportSheet by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        vm.events.receiveAsFlow().collect { e ->
            when (e) {
                is EditorViewModel.Event.Msg -> snack.showSnackbar(ctx.getString(e.id))
                is EditorViewModel.Event.Share -> {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "image/png"
                        putExtra(Intent.EXTRA_STREAM, e.uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    ctx.startActivity(Intent.createChooser(send, null))
                }
            }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.app_name), fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onNew) {
                        Icon(Icons.Rounded.AddPhotoAlternate, stringResource(R.string.new_image))
                    }
                },
                actions = {
                    IconButton(onClick = vm::undo, enabled = vm.canUndo) {
                        Icon(Icons.AutoMirrored.Rounded.Undo, stringResource(R.string.undo))
                    }
                    IconButton(onClick = vm::redo, enabled = vm.canRedo) {
                        Icon(Icons.AutoMirrored.Rounded.Redo, stringResource(R.string.redo))
                    }
                    HoldCompare(vm)
                    IconButton(onClick = { exportSheet = true }) {
                        Icon(Icons.Rounded.SaveAlt, stringResource(R.string.save))
                    }
                    Box {
                        IconButton(onClick = { menu = true }) {
                            Icon(Icons.Rounded.MoreVert, stringResource(R.string.more))
                        }
                        MoreMenu(vm, menu) { menu = false }
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                CanvasArea(vm)
                if (vm.exporting || vm.refining) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
            ToolPanel(vm)
        }
    }

    if (vm.refineOpen) RefineSheet(vm)
    if (exportSheet) ExportSheet(vm) { exportSheet = false }
}

@Composable
private fun HoldCompare(vm: EditorViewModel) {
    Box(
        Modifier.size(48.dp).pointerInput(Unit) {
            detectTapGestures(onPress = {
                vm.compare(true)
                tryAwaitRelease()
                vm.compare(false)
            })
        },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Rounded.Compare, stringResource(R.string.compare),
            tint = if (vm.showOriginal) MaterialTheme.colorScheme.primary else LocalContentColor.current
        )
    }
}

@Composable
private fun MoreMenu(vm: EditorViewModel, expanded: Boolean, onDismiss: () -> Unit) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        Text(
            stringResource(R.string.background),
            Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelLarge
        )
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Bg.values().forEach { b ->
                val sel = vm.bg == b
                Box(
                    Modifier.size(32.dp).clip(CircleShape)
                        .border(
                            if (sel) 3.dp else 1.dp,
                            if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                            CircleShape
                        )
                        .clickable { vm.bg = b }
                ) {
                    if (b == Bg.CHECKER) {
                        Row(Modifier.fillMaxSize()) {
                            Box(Modifier.weight(1f).fillMaxHeight().background(Color(0xFFCCCCCC)))
                            Box(Modifier.weight(1f).fillMaxHeight().background(Color.White))
                        }
                    } else {
                        Box(Modifier.fillMaxSize().background(Color(bgColor(b))))
                    }
                }
            }
        }
        HorizontalDivider()
        ToggleItem(R.string.loupe, vm.loupe) { vm.loupe = it }
        ToggleItem(R.string.finger_offset, vm.fingerOffset) { vm.fingerOffset = it }
        ToggleItem(R.string.overlay, vm.overlay) { vm.changeOverlay(it) }
        HorizontalDivider()
        DropdownMenuItem(
            text = { Text(stringResource(R.string.fit)) },
            leadingIcon = { Icon(Icons.Rounded.FitScreen, null) },
            onClick = { vm.fit(); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text(stringResource(R.string.invert)) },
            leadingIcon = { Icon(Icons.Rounded.InvertColors, null) },
            onClick = { vm.invert(); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text(stringResource(R.string.reset)) },
            leadingIcon = { Icon(Icons.Rounded.RestartAlt, null) },
            onClick = { vm.resetMask(); onDismiss() }
        )
    }
}

@Composable
private fun ToggleItem(@StringRes label: Int, checked: Boolean, onChange: (Boolean) -> Unit) {
    DropdownMenuItem(
        text = { Text(stringResource(label)) },
        onClick = { onChange(!checked) },
        trailingIcon = { Switch(checked = checked, onCheckedChange = null) }
    )
}

// ============================ canvas ============================

@Composable
private fun CanvasArea(vm: EditorViewModel) {
    val dens = LocalDensity.current.density
    val checker = remember(dens) { makeChecker(8f * dens) }
    val bgPaint = remember { android.graphics.Paint() }
    val imgPaint = remember { android.graphics.Paint() }

    fun drawBg(nc: android.graphics.Canvas, l: Float, t: Float, r: Float, b: Float) {
        bgPaint.shader = if (vm.bg == Bg.CHECKER) checker else null
        bgPaint.color = bgColor(vm.bg)
        nc.drawRect(l, t, r, b, bgPaint)
    }

    Canvas(
        Modifier
            .fillMaxSize()
            .clipToBounds()
            .onSizeChanged { vm.onViewSize(it) }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val slop = viewConfiguration.touchSlop
                    val start = down.position
                    var pinch = false
                    var started = false
                    var cancelled = false
                    do {
                        val event = awaitPointerEvent()
                        val pressed = event.changes.count { it.pressed }
                        if (pressed >= 2) {
                            if (started) { vm.strokeCancel(); started = false }
                            pinch = true
                            val zoom = event.calculateZoom()
                            val pan = event.calculatePan()
                            val centroid = event.calculateCentroid()
                            if (zoom != 1f || pan != Offset.Zero) vm.transform(zoom, pan, centroid)
                            event.changes.forEach { it.consume() }
                        } else if (!pinch) {
                            val ch = event.changes.firstOrNull { it.id == down.id }
                            if (ch == null) { cancelled = true; break }
                            if (vm.tool == Tool.ZOOM) {
                                val delta = ch.positionChange()
                                if (delta != Offset.Zero) {
                                    vm.transform(1f, delta, ch.position)
                                    ch.consume()
                                }
                            } else {
                                if (!started && (ch.position - start).getDistance() > slop) {
                                    started = true
                                    vm.strokeBegin(start)
                                }
                                if (started) {
                                    vm.strokeMove(ch.position)
                                    ch.consume()
                                }
                            }
                        }
                    } while (event.changes.any { it.pressed })
                    if (!pinch && !cancelled) {
                        if (started) vm.strokeEnd() else if (vm.tool != Tool.ZOOM) vm.tap(start)
                    } else if (started) {
                        vm.strokeCancel()
                    }
                }
            }
    ) {
        val tick = vm.version
        val d = vm.doc ?: return@Canvas
        val s = vm.scale
        val o = vm.offset
        val bmp = d.bitmap

        drawIntoCanvas { c ->
            val nc = c.nativeCanvas
            drawBg(nc, o.x, o.y, o.x + d.w * s, o.y + d.h * s)
            imgPaint.isFilterBitmap = s < 3f
            nc.save()
            nc.translate(o.x, o.y)
            nc.scale(s, s)
            nc.drawBitmap(bmp, 0f, 0f, imgPaint)
            nc.restore()
        }

        val tint = if (vm.erase) Color(0xFFFF5252) else Color(0xFF69F0AE)

        if (vm.tool == Tool.SELECT && vm.lasso.size > 1) {
            val p = Path()
            vm.lasso.forEachIndexed { i, q ->
                val sx = q.x * s + o.x
                val sy = q.y * s + o.y
                if (i == 0) p.moveTo(sx, sy) else p.lineTo(sx, sy)
            }
            p.close()
            drawPath(p, tint.copy(alpha = 0.22f))
            drawPath(p, Color.Black, style = Stroke(3.5f.dp.toPx()))
            drawPath(p, Color.White, style = Stroke(1.8f.dp.toPx()))
        }

        val cur = vm.cursor
        if (cur != null && !vm.showOriginal) {
            when (vm.tool) {
                Tool.MANUAL, Tool.BRUSH -> {
                    val rr = vm.brushSize.dp.toPx() / 2f
                    drawCircle(Color.Black, rr + 1.dp.toPx(), cur, style = Stroke(1.dp.toPx()))
                    drawCircle(tint, rr, cur, style = Stroke(1.6f.dp.toPx()))
                }
                Tool.AUTO -> {
                    val rr = 10.dp.toPx()
                    drawCircle(Color.Black, rr + 1.dp.toPx(), cur, style = Stroke(1.dp.toPx()))
                    drawCircle(tint, rr, cur, style = Stroke(1.6f.dp.toPx()))
                }
                Tool.SELECT, Tool.ZOOM -> drawCircle(tint, 4.dp.toPx(), cur)
            }
        }

        if (vm.loupe && !vm.showOriginal && vm.touch != null && vm.tool != Tool.SELECT && vm.tool != Tool.ZOOM) {
            drawLoupe(vm, bmp, imgPaint, ::drawBg)
        }
    }
}

private fun DrawScope.drawLoupe(
    vm: EditorViewModel,
    bmp: android.graphics.Bitmap,
    imgPaint: android.graphics.Paint,
    drawBg: (android.graphics.Canvas, Float, Float, Float, Float) -> Unit
) {
    val t = vm.touch ?: return
    val rad = 56.dp.toPx()
    val margin = 16.dp.toPx()
    val c = Offset(if (t.x < size.width / 2f) size.width - rad - margin else rad + margin, rad + margin)
    val zoom = 2.5f
    val ip = vm.toImg(vm.cursor ?: t)
    val clip = Path().apply { addOval(Rect(c, rad)) }
    clipPath(clip) {
        drawIntoCanvas { cv ->
            val nc = cv.nativeCanvas
            drawBg(nc, c.x - rad, c.y - rad, c.x + rad, c.y + rad)
            nc.save()
            nc.translate(c.x, c.y)
            nc.scale(vm.scale * zoom, vm.scale * zoom)
            nc.translate(-ip.x, -ip.y)
            imgPaint.isFilterBitmap = false
            nc.drawBitmap(bmp, 0f, 0f, imgPaint)
            nc.restore()
        }
    }
    val tint = if (vm.erase) Color(0xFFFF5252) else Color(0xFF69F0AE)
    val ring = if (vm.tool == Tool.AUTO) 10.dp.toPx() * zoom / 2f else vm.brushSize.dp.toPx() / 2f * zoom
    if (ring < rad - 4.dp.toPx()) {
        drawCircle(Color.Black, ring + 1.dp.toPx(), c, style = Stroke(1.dp.toPx()))
        drawCircle(tint, ring, c, style = Stroke(1.6f.dp.toPx()))
    }
    drawCircle(tint, 2.dp.toPx(), c)
    drawCircle(Color.Black, rad, c, style = Stroke(5.dp.toPx()))
    drawCircle(Color.White, rad, c, style = Stroke(2.5f.dp.toPx()))
}

// ============================ tool panel ============================

@Composable
private fun ToolPanel(vm: EditorViewModel) {
    Surface(
        tonalElevation = 3.dp,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            Modifier.navigationBarsPadding().padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SingleChoiceSegmentedButtonRow(Modifier.weight(1f)) {
                    SegmentedButton(
                        selected = vm.erase,
                        onClick = { vm.erase = true },
                        shape = SegmentedButtonDefaults.itemShape(0, 2)
                    ) { Text(stringResource(R.string.mode_erase)) }
                    SegmentedButton(
                        selected = !vm.erase,
                        onClick = { vm.erase = false },
                        shape = SegmentedButtonDefaults.itemShape(1, 2)
                    ) { Text(stringResource(R.string.mode_keep)) }
                }
                FilledTonalIconButton(onClick = vm::openRefine) {
                    Icon(Icons.Rounded.Tune, stringResource(R.string.refine))
                }
            }

            Text(
                stringResource(
                    when (vm.tool) {
                        Tool.AUTO -> R.string.hint_auto
                        Tool.MANUAL -> R.string.hint_manual
                        Tool.BRUSH -> R.string.hint_brush
                        Tool.SELECT -> R.string.hint_select
                        Tool.ZOOM -> R.string.hint_zoom
                    }
                ),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            when (vm.tool) {
                Tool.AUTO -> {
                    LabeledSlider(R.string.tolerance, vm.tolerance, 0f..100f, vm.tolerance.roundToInt().toString()) { vm.tolerance = it }
                    SwitchRow(R.string.contiguous, vm.contiguous) { vm.contiguous = it }
                }
                Tool.MANUAL -> {
                    LabeledSlider(R.string.size, vm.brushSize, 12f..140f, vm.brushSize.roundToInt().toString()) { vm.brushSize = it }
                    LabeledSlider(R.string.tolerance, vm.tolerance, 0f..100f, vm.tolerance.roundToInt().toString()) { vm.tolerance = it }
                    LabeledSlider(R.string.edge, vm.edgeSens, 0f..100f, vm.edgeSens.roundToInt().toString()) { vm.edgeSens = it }
                }
                Tool.BRUSH -> {
                    LabeledSlider(R.string.size, vm.brushSize, 6f..140f, vm.brushSize.roundToInt().toString()) { vm.brushSize = it }
                    LabeledSlider(R.string.hardness, vm.hardness, 0f..1f, "${(vm.hardness * 100).roundToInt()}%") { vm.hardness = it }
                    LabeledSlider(R.string.strength, vm.strength, 0.05f..1f, "${(vm.strength * 100).roundToInt()}%") { vm.strength = it }
                }
                Tool.SELECT -> SwitchRow(R.string.lasso_outside, vm.lassoOutside) { vm.lassoOutside = it }
                Tool.ZOOM -> ZoomControls(vm)
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                ToolItem(vm, Tool.AUTO, Icons.Rounded.AutoFixHigh, R.string.tool_auto)
                ToolItem(vm, Tool.MANUAL, Icons.Rounded.TouchApp, R.string.tool_manual)
                ToolItem(vm, Tool.BRUSH, Icons.Rounded.Brush, R.string.tool_brush)
                ToolItem(vm, Tool.SELECT, Icons.Rounded.HighlightAlt, R.string.tool_select)
                ToolItem(vm, Tool.ZOOM, Icons.Rounded.ZoomIn, R.string.tool_zoom)
            }
        }
    }
}

@Composable
private fun RowScope.ToolItem(
    vm: EditorViewModel,
    tool: Tool,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    @StringRes label: Int
) {
    val sel = vm.tool == tool
    val scheme = MaterialTheme.colorScheme
    Column(
        Modifier
            .weight(1f)
            .clip(RoundedCornerShape(16.dp))
            .clickable { vm.tool = tool }
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(width = 56.dp, height = 32.dp)
                .clip(CircleShape)
                .background(if (sel) scheme.secondaryContainer else Color.Transparent),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = if (sel) scheme.onSecondaryContainer else scheme.onSurfaceVariant)
        }
        Text(
            stringResource(label),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
            color = if (sel) scheme.onSurface else scheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun ZoomControls(vm: EditorViewModel) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { vm.zoomBy(1f / 1.5f) }) {
            Icon(Icons.Rounded.ZoomOut, stringResource(R.string.zoom_out))
        }
        Slider(vm.zoomFraction, vm::applyZoomFraction, Modifier.weight(1f))
        IconButton(onClick = { vm.zoomBy(1.5f) }) {
            Icon(Icons.Rounded.ZoomIn, stringResource(R.string.zoom_in))
        }
        Text(
            "${(vm.scale * 100).roundToInt()}%",
            Modifier.width(52.dp),
            textAlign = TextAlign.End,
            style = MaterialTheme.typography.labelMedium
        )
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilledTonalButton(onClick = vm::fit, modifier = Modifier.weight(1f)) {
            Icon(Icons.Rounded.FitScreen, null)
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.fit))
        }
        FilledTonalButton(onClick = { vm.zoomTo(1f) }, modifier = Modifier.weight(1f)) {
            Text("1:1")
        }
    }
}

@Composable
private fun LabeledSlider(
    @StringRes label: Int,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    text: String,
    onChange: (Float) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            stringResource(label),
            Modifier.width(104.dp),
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Slider(value, onChange, Modifier.weight(1f), valueRange = range)
        Text(text, Modifier.width(44.dp), textAlign = TextAlign.End, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun SwitchRow(@StringRes label: Int, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(stringResource(label), Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
        Switch(checked = checked, onCheckedChange = null)
    }
}

// ============================ sheets ============================

@Composable
private fun RefineSheet(vm: EditorViewModel) {
    ModalBottomSheet(
        onDismissRequest = vm::cancelRefine,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        scrimColor = Color.Transparent
    ) {
        Column(
            Modifier.padding(start = 24.dp, end = 24.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(stringResource(R.string.refine), style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.smooth), style = MaterialTheme.typography.titleSmall)
            Text(
                stringResource(R.string.smooth_hint),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                for (lv in 1..5) {
                    SegmentedButton(
                        selected = vm.rSmoothLevel == lv,
                        onClick = { vm.pickSmooth(lv) },
                        shape = SegmentedButtonDefaults.itemShape(lv - 1, 5),
                        icon = {}
                    ) { Text(lv.toString()) }
                }
            }
            LabeledSlider(R.string.shift, vm.rShift, -10f..10f, vm.rShift.roundToInt().toString()) {
                vm.rShift = it.roundToInt().toFloat(); vm.refinePreview()
            }
            LabeledSlider(R.string.feather, vm.rFeather, 0f..20f, vm.rFeather.roundToInt().toString()) {
                vm.rFeather = it.roundToInt().toFloat(); vm.refinePreview()
            }
            Spacer(Modifier.size(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = vm::cancelRefine, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.cancel))
                }
                Button(onClick = vm::applyRefine, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.apply))
                }
            }
        }
    }
}

@Composable
private fun ExportSheet(vm: EditorViewModel, onClose: () -> Unit) {
    var trim by remember { mutableStateOf(false) }
    ModalBottomSheet(onDismissRequest = onClose) {
        Column(
            Modifier.padding(start = 24.dp, end = 24.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SwitchRow(R.string.trim, trim) { trim = it }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FilledTonalButton(
                    onClick = { vm.export(trim, true); onClose() },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.Share, null)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.share))
                }
                Button(
                    onClick = { vm.export(trim, false); onClose() },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.SaveAlt, null)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.save))
                }
            }
        }
    }
}
