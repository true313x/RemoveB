package com.removeb.app.engine

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Shader
import kotlin.math.max
import kotlin.math.roundToInt

fun makeChecker(cellPx: Float): BitmapShader {
    val n = max(4, cellPx.roundToInt())
    val bmp = Bitmap.createBitmap(n * 2, n * 2, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    c.drawColor(0xFFFFFFFF.toInt())
    val p = Paint().apply { color = 0xFFD0D0D0.toInt() }
    c.drawRect(0f, 0f, n.toFloat(), n.toFloat(), p)
    c.drawRect(n.toFloat(), n.toFloat(), 2f * n, 2f * n, p)
    return BitmapShader(bmp, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
}
