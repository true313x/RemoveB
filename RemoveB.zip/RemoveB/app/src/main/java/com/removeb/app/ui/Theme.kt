package com.removeb.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Brand palette taken from the app icon: electric blue -> indigo, cyan accent, ink-navy.
private val LightColors = lightColorScheme(
    primary = Color(0xFF2455E6),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFDCE4FF),
    onPrimaryContainer = Color(0xFF001A5E),
    inversePrimary = Color(0xFFB6C4FF),
    secondary = Color(0xFF5B44D6),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFE4DEFF),
    onSecondaryContainer = Color(0xFF1A0A6B),
    tertiary = Color(0xFF006C8E),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFC2EAFF),
    onTertiaryContainer = Color(0xFF001F2D),
    background = Color(0xFFFAF8FF),
    onBackground = Color(0xFF1A1B22),
    surface = Color(0xFFFAF8FF),
    onSurface = Color(0xFF1A1B22),
    surfaceVariant = Color(0xFFE2E1EC),
    onSurfaceVariant = Color(0xFF45464F),
    surfaceTint = Color(0xFF2455E6),
    inverseSurface = Color(0xFF2F3037),
    inverseOnSurface = Color(0xFFF1F0FA),
    outline = Color(0xFF767680),
    outlineVariant = Color(0xFFC6C5D0),
    surfaceBright = Color(0xFFFAF8FF),
    surfaceDim = Color(0xFFDAD9E2),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF4F3FB),
    surfaceContainer = Color(0xFFEEEDF6),
    surfaceContainerHigh = Color(0xFFE8E7F0),
    surfaceContainerHighest = Color(0xFFE2E1EA)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFB6C4FF),
    onPrimary = Color(0xFF0A2A85),
    primaryContainer = Color(0xFF1D3FB0),
    onPrimaryContainer = Color(0xFFDCE4FF),
    inversePrimary = Color(0xFF2455E6),
    secondary = Color(0xFFC9BEFF),
    onSecondary = Color(0xFF2F1B8F),
    secondaryContainer = Color(0xFF442ABD),
    onSecondaryContainer = Color(0xFFE4DEFF),
    tertiary = Color(0xFF68D4FF),
    onTertiary = Color(0xFF003548),
    tertiaryContainer = Color(0xFF004D68),
    onTertiaryContainer = Color(0xFFC2EAFF),
    background = Color(0xFF121318),
    onBackground = Color(0xFFE3E1EB),
    surface = Color(0xFF121318),
    onSurface = Color(0xFFE3E1EB),
    surfaceVariant = Color(0xFF45464F),
    onSurfaceVariant = Color(0xFFC6C5D0),
    surfaceTint = Color(0xFFB6C4FF),
    inverseSurface = Color(0xFFE3E1EB),
    inverseOnSurface = Color(0xFF2F3037),
    outline = Color(0xFF90909A),
    outlineVariant = Color(0xFF45464F),
    surfaceBright = Color(0xFF38393F),
    surfaceDim = Color(0xFF121318),
    surfaceContainerLowest = Color(0xFF0D0E13),
    surfaceContainerLow = Color(0xFF1A1B20),
    surfaceContainer = Color(0xFF1E1F25),
    surfaceContainerHigh = Color(0xFF292A2F),
    surfaceContainerHighest = Color(0xFF34343A)
)

@Composable
fun RemoveBTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
