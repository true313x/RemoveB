package com.removeb.app

import android.app.Application
import android.content.ContentValues
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.StringRes
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.IntSize
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.removeb.app.engine.Doc
import com.removeb.app.engine.decodeDoc
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    enum class Tool { AUTO, MAGIC, BRUSH, LASSO }
    enum class Bg { CHECKER, WHITE, BLACK, GREEN, MAGENTA }

    sealed interface Event {
        data class Msg(@StringRes val id: Int) : Event
        data class Share(val uri: Uri) : Event
    }

    val events = Channel<Event>(Channel.BUFFERED)

    // ----- document state -----
    var doc by mutableStateOf<Doc?>(null)
        private set
    var version by mutableIntStateOf(0)
        private set
    var loading by mutableStateOf(false)
        private set
    var exporting by mutableStateOf(false)
        private set
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set

    // ----- tool settings -----
    var tool by mutableStateOf(Tool.AUTO)
    var erase by mutableStateOf(true)
    var tolerance by mutableFloatStateOf(30f)
    var contiguous by mutableStateOf(true)
    var brushSize by mutableFloatStateOf(44f)      // dp
    var hardness by mutableFloatStateOf(0.85f)
    var strength by mutableFloatStateOf(1f)
    var edgeSens by mutableFloatStateOf(50f)
    var lassoOutside by mutableStateOf(false)
    var loupe by mutableStateOf(true)
    var fingerOffset by mutableStateOf(false)
    var bg by mutableStateOf(Bg.CHECKER)
    var showOriginal by mutableStateOf(false)
        private set
    var overlay by mutableStateOf(false)
        private set

    // ----- view transform -----
    var scale by mutableFloatStateOf(1f)
        private set
    var offset by mutableStateOf(Offset.Zero)
        private set
    var cursor by mutableStateOf<Offset?>(null)
        private set
    var touch by mutableStateOf<Offset?>(null)
        private set
    val lasso = mutableStateListOf<Offset>()
    var density = 3f

    private var viewSize = IntSize.Zero
    private var fitScale = 1f
    private var needFit = true
    private var stroking = false
    private var last = Offset.Zero

    // ----- refine -----
    var refineOpen by mutableStateOf(false)
        private set
    var refining by mutableStateOf(false)
        private set
    var rShift by mutableFloatStateOf(0f)
    var rSmooth by mutableFloatStateOf(0f)
    var rFeather by mutableFloatStateOf(0f)
    private var refineJob: Job? = null

    // ================= loading =================

    fun load(uri: Uri) {
        if (loading) return
        viewModelScope.launch {
            loading = true
            try {
                val d = withContext(Dispatchers.Default) {
                    decodeDoc(getApplication<Application>().contentResolver, uri, MAX_EDGE).also { it.refreshAll() }
                }
                doc = d
                showOriginal = false
                overlay = false
                lasso.clear()
                needFit = true
                tryFit()
                afterEdit()
            } catch (t: Throwable) {
                events.trySend(Event.Msg(R.string.load_failed))
            }
            loading = false
        }
    }

    // ================= view =================

    fun onViewSize(sz: IntSize) {
        viewSize = sz
        if (needFit) tryFit()
    }

    private fun tryFit() {
        if (doc == null || viewSize.width <= 0 || viewSize.height <= 0) return
        fit()
        needFit = false
    }

    fun fit() {
        val d = doc ?: return
        val vw = viewSize.width.toFloat()
        val vh = viewSize.height.toFloat()
        if (vw <= 0f || vh <= 0f) return
        val s = min(vw / d.w, vh / d.h) * 0.97f
        fitScale = s
        scale = s
        offset = Offset((vw - d.w * s) / 2f, (vh - d.h * s) / 2f)
    }

    fun transform(zoom: Float, pan: Offset, c: Offset) {
        val ns = (scale * zoom).coerceIn(fitScale * 0.5f, 40f)
        val f = ns / scale
        offset = c - (c - offset) * f + pan
        scale = ns
    }

    fun toImg(p: Offset) = Offset((p.x - offset.x) / scale, (p.y - offset.y) / scale)

    private fun eff(p: Offset) = if (fingerOffset) Offset(p.x, p.y - 64f * density) else p

    private fun radius() = max(0.5f, brushSize * density / 2f / scale)

    // ================= tools =================

    private fun dab(d: Doc, q: Offset) {
        when (tool) {
            Tool.MAGIC -> d.magicDab(
                floor(q.x).toInt(), floor(q.y).toInt(),
                radius().roundToInt().coerceAtLeast(2), tolerance, edgeSens, erase
            )
            Tool.BRUSH -> d.brushDab(q.x, q.y, radius(), hardness, strength, erase)
            else -> Unit
        }
    }

    fun tap(p: Offset) {
        val d = doc ?: return
        val q = toImg(eff(p))
        d.beginOp()
        when (tool) {
            Tool.AUTO -> d.fill(floor(q.x).toInt(), floor(q.y).toInt(), tolerance, contiguous, erase)
            Tool.MAGIC, Tool.BRUSH -> dab(d, q)
            Tool.LASSO -> Unit
        }
        d.endOp()
        afterEdit()
    }

    fun strokeBegin(p: Offset) {
        val d = doc ?: return
        stroking = true
        touch = p
        cursor = eff(p)
        val q = toImg(eff(p))
        d.beginOp()
        when (tool) {
            Tool.AUTO -> Unit
            Tool.LASSO -> { lasso.clear(); lasso.add(q) }
            Tool.MAGIC, Tool.BRUSH -> { dab(d, q); last = q }
        }
        version++
    }

    fun strokeMove(p: Offset) {
        if (!stroking) return
        val d = doc ?: return
        touch = p
        cursor = eff(p)
        val q = toImg(eff(p))
        when (tool) {
            Tool.AUTO -> Unit
            Tool.LASSO -> {
                val l = lasso.lastOrNull()
                if (l == null || hypot(q.x - l.x, q.y - l.y) * scale >= 3f) lasso.add(q)
            }
            Tool.MAGIC, Tool.BRUSH -> {
                val spacing = max(1f, radius() * if (tool == Tool.MAGIC) 0.35f else 0.12f)
                val dx = q.x - last.x
                val dy = q.y - last.y
                val dist = hypot(dx, dy)
                if (dist >= spacing) {
                    val n = (dist / spacing).toInt()
                    val ux = dx / dist
                    val uy = dy / dist
                    for (i in 1..n) dab(d, Offset(last.x + ux * spacing * i, last.y + uy * spacing * i))
                    last = Offset(last.x + ux * spacing * n, last.y + uy * spacing * n)
                }
            }
        }
        version++
    }

    fun strokeEnd() {
        if (!stroking) return
        stroking = false
        val d = doc
        val tp = touch
        if (d != null) {
            when (tool) {
                Tool.AUTO -> if (tp != null) {
                    val q = toImg(eff(tp))
                    d.fill(floor(q.x).toInt(), floor(q.y).toInt(), tolerance, contiguous, erase)
                }
                Tool.LASSO -> if (lasso.size >= 3) {
                    val path = android.graphics.Path()
                    lasso.forEachIndexed { i, o -> if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
                    d.lasso(path, lassoOutside, erase)
                }
                else -> Unit
            }
            d.endOp()
        }
        lasso.clear()
        touch = null
        cursor = null
        afterEdit()
    }

    fun strokeCancel() {
        if (!stroking) return
        stroking = false
        doc?.cancelOp()
        lasso.clear()
        touch = null
        cursor = null
        afterEdit()
    }

    // ================= history / view modes =================

    private fun afterEdit() {
        canUndo = doc?.canUndo == true
        canRedo = doc?.canRedo == true
        version++
    }

    fun undo() { doc?.undo(); afterEdit() }
    fun redo() { doc?.redo(); afterEdit() }
    fun invert() { doc?.invert(); afterEdit() }
    fun resetMask() { doc?.resetMask(); afterEdit() }

    fun compare(on: Boolean) {
        val d = doc ?: return
        showOriginal = on
        if (on) d.showOriginal() else d.refreshAll()
        version++
    }

    fun changeOverlay(v: Boolean) {
        overlay = v
        doc?.let { it.overlay = v; it.refreshAll() }
        version++
    }

    // ================= refine =================

    fun openRefine() {
        if (doc == null) return
        rShift = 0f; rSmooth = 0f; rFeather = 0f
        refineOpen = true
    }

    fun refinePreview() {
        val d = doc ?: return
        val s = rShift.roundToInt()
        val sm = rSmooth.roundToInt()
        val f = rFeather.roundToInt()
        val prev = refineJob
        refineJob = viewModelScope.launch {
            prev?.cancelAndJoin()
            delay(100)
            refining = true
            try {
                withContext(Dispatchers.Default) { d.refreshAll(d.refined(s, sm, f)) }
                version++
            } finally {
                refining = false
            }
        }
    }

    fun applyRefine() {
        val d = doc ?: return
        val s = rShift.roundToInt()
        val sm = rSmooth.roundToInt()
        val f = rFeather.roundToInt()
        viewModelScope.launch {
            refineJob?.cancelAndJoin()
            refining = true
            withContext(Dispatchers.Default) { d.commitRefined(d.refined(s, sm, f)) }
            refining = false
            refineOpen = false
            afterEdit()
        }
    }

    fun cancelRefine() {
        viewModelScope.launch {
            refineJob?.cancelAndJoin()
            val d = doc
            if (d != null) withContext(Dispatchers.Default) { d.refreshAll() }
            refineOpen = false
            version++
        }
    }

    // ================= export =================

    fun export(trim: Boolean, share: Boolean) {
        val d = doc ?: return
        if (exporting) return
        viewModelScope.launch {
            exporting = true
            try {
                val uri = withContext(Dispatchers.IO) {
                    val bmp = d.export(trim)
                    try { saveToGallery(bmp) } finally { bmp.recycle() }
                }
                events.send(if (share) Event.Share(uri) else Event.Msg(R.string.saved))
            } catch (t: Throwable) {
                events.send(Event.Msg(R.string.save_failed))
            }
            exporting = false
        }
    }

    private fun saveToGallery(bmp: Bitmap): Uri {
        val cr = getApplication<Application>().contentResolver
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "RemoveB_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/RemoveB")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: error("insert failed")
        try {
            val ok = cr.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            if (!ok) error("compress failed")
            cv.clear()
            cv.put(MediaStore.Images.Media.IS_PENDING, 0)
            cr.update(uri, cv, null, null)
        } catch (t: Throwable) {
            cr.delete(uri, null, null)
            throw t
        }
        return uri
    }

    companion object {
        const val MAX_EDGE = 3072
    }
}
