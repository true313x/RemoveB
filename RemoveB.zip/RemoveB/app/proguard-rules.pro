# RemoveB: no reflection, default rules are enough.
